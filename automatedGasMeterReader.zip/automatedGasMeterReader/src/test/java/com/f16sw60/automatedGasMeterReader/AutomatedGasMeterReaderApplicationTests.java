package com.f16sw60.automatedGasMeterReader;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutomatedGasMeterReaderApplicationTests {

	@Test
	void contextLoads() {
	}

}
