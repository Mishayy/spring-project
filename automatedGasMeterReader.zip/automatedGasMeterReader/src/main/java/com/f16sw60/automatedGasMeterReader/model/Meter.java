package com.f16sw60.automatedGasMeterReader.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Table(name="meter")
@Entity
public class Meter {
	@Id
	@GeneratedValue
	@Column(name="id",updatable = false)
	private Integer Id;
	
	@Column(name="meterunits")
	private Integer meterUnits;
	
	@Column(name="metertype")
	private String type;
	
	@ManyToOne
    @JoinColumn(name = "consumerId", nullable = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private Consumers consumer;
	

	public Integer getId() {
		return Id;
	}

	public void setId(Integer id) {
		Id = id;
	}

	public Integer getMeterUnits() {
		return meterUnits;
	}

	public void setMeterUnits(Integer meterUnits) {
		this.meterUnits = meterUnits;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Consumers getConsumer() {
		return consumer;
	}

	public void setConsumer(Consumers consumer) {
		this.consumer = consumer;
	}
	
}
