package com.f16sw60.automatedGasMeterReader.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.f16sw60.automatedGasMeterReader.exception.ResourceNotFoundException;
import com.f16sw60.automatedGasMeterReader.model.Consumers;
import com.f16sw60.automatedGasMeterReader.model.Meter;
import com.f16sw60.automatedGasMeterReader.repository.ConsumerRepository;
import com.f16sw60.automatedGasMeterReader.repository.MeterRepository;

@RestController
public class MeterController {
	@Autowired
	private ConsumerRepository consumerRepository;
	
	@Autowired
	private MeterRepository meterRepository;
	
	@PostMapping(value = "/consumers/{consumerId}/meter")
	@ResponseStatus(code = HttpStatus.CREATED)
	public Meter save(@PathVariable Integer consumerId,@RequestBody Meter  meter) {
		return consumerRepository.findById(consumerId).map(consumer -> {
			meter.setConsumer(consumer);
			return meterRepository.save(meter);
			
		}).orElseThrow(() -> new ResourceNotFoundException("Consumer [consumerId="+consumerId+"] can't be found"));

	 }
	
	@GetMapping(value = "/consumers/{consumerId}/meter") 
	 public List<Meter> all (@PathVariable Integer consumerId){ 
              return meterRepository.findByConsumer_id(consumerId);
	 } 
	
	@GetMapping(value = "/consumers/{consumerId}/meter/{id}") 
	 public ResponseEntity<Meter> getById (@PathVariable Integer id){ 
             return ResponseEntity.ok().body(meterRepository.findById(id).get());
	 } 
	
	@DeleteMapping(value = "/consumers/{consumerId}/meter/{meterId}")
	public ResponseEntity<?> deleteAccount(@PathVariable Integer consumerId,@PathVariable Integer meterId){

		if (!consumerRepository.existsById(consumerId)) {
			throw new ResourceNotFoundException("Consumer [consumerId="+consumerId+"] can't be found");
		}
		
		return meterRepository.findById(meterId).map(account ->{
			   meterRepository.delete(account);
			   return ResponseEntity.ok().build();
		       }).orElseThrow(() -> new ResourceNotFoundException("Meter [meterId="+meterId+"] can't be found"));

	}
	
	@PutMapping(value = "/consumers/{consumerId}/meter/{meterId}")
	public ResponseEntity<Meter> updateAccount(@PathVariable Integer consumerId,@PathVariable Integer meterId,@RequestBody Meter newMeter){

		Consumers consumer = consumerRepository.findById(consumerId).orElseThrow(() -> new ResourceNotFoundException("Consumer [consumerId="+consumerId+"] can't be found"));
		
		return meterRepository.findById(meterId).map(meter ->{
				meter.setMeterUnits(newMeter.getMeterUnits());
				meter.setConsumer(consumer);
				meter.setType(newMeter.getType());
			   meterRepository.save(meter);
			   return ResponseEntity.ok(meter);
		       }).orElseThrow(() -> new ResourceNotFoundException("Meter [meterId="+meterId+"] can't be found"));		
	}
}
