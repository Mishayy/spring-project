package com.f16sw60.automatedGasMeterReader.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.f16sw60.automatedGasMeterReader.model.Meter;

public interface MeterRepository extends JpaRepository<Meter, Integer>{
	List<Meter> findByConsumer_id(int id);
}
