package com.f16sw60.automatedGasMeterReader.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.f16sw60.automatedGasMeterReader.exception.ResourceNotFoundException;
import com.f16sw60.automatedGasMeterReader.model.Consumers;
import com.f16sw60.automatedGasMeterReader.repository.ConsumerRepository;

@RestController
public class ConsumerController {

	@Autowired
	private ConsumerRepository consumerRepository;
	
	
	@PostMapping(value = "/consumers")
	@ResponseStatus(code = HttpStatus.CREATED)
	public ResponseEntity<Consumers> create(@RequestBody Consumers consumers) {
		return ResponseEntity.ok().body(consumerRepository.save(consumers));
	 }
	
	@GetMapping(value = "/consumers")
	public ResponseEntity<List<Consumers>> getAll(){
		return ResponseEntity.ok().body(consumerRepository.findAll());
	}
	
	@GetMapping(value = "/consumers/{id}")
	public ResponseEntity<Consumers> getById(@PathVariable int id){
		return ResponseEntity.ok().body(consumerRepository.findById(id).get());
	}
	
	@DeleteMapping(value = "/consumers/{id}")
	public HttpStatus delete(@PathVariable int id){
		consumerRepository.deleteById(id);
		return HttpStatus.OK;
	}
	
	@PutMapping(value = "/consumers/{id}")
	public ResponseEntity<Consumers> update(@PathVariable int id,@RequestBody Consumers consumers){
		return consumerRepository.findById(id).map(data -> {
			data.setAddress(consumers.getAddress());
			data.setConsumerName(consumers.getConsumerName());
			data.setPhone(consumers.getPhone());
			consumerRepository.save(data);
			return ResponseEntity.ok(data);
		}).orElseThrow(() -> new ResourceNotFoundException("consumers [id="+id+"] can't be found"));
	}
}
