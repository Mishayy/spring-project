package com.f16sw60.automatedGasMeterReader.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.f16sw60.automatedGasMeterReader.model.Consumers;

public interface ConsumerRepository extends JpaRepository<Consumers, Integer>{

}
